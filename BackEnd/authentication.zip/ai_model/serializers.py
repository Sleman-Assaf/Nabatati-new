from rest_framework import serializers


class ImageDiagnosisRequestSerializer(serializers.Serializer):
    image = serializers.ImageField()

class ImageDiagnosisResponseSerializer(serializers.Serializer):
    status = serializers.CharField()  # "Healthy" أو "Infected"
    disease_type = serializers.CharField(allow_null=True, required=False)  # اسم المرض (يمكن أن يكون null)
    confidence = serializers.FloatField()  # نسبة الثقة

    


