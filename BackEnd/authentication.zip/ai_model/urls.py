
from django.urls import path
from . views import ImageDiagnosisAPIView
from ai_model import views


urlpatterns = [
    path('model/', ImageDiagnosisAPIView.as_view(), name='image-diagnosis'),
]
