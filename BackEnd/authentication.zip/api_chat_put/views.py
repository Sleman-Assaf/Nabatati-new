import requests
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import QuestionSerializer
import langdetect

# عنوان Gemini API
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-001:generateContent"

# مفتاح API - يُفضل تخزينه في settings.py أو .env
API_KEY = "AIzaSyBJF0PCjGCPfsIs3Ow7V_EJPb9re5mDhRM"  # استبدله لاحقاً

class AskGeminiAPIView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = QuestionSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        question = serializer.validated_data['question']

        # ✅ التحقق إذا السؤال غير متعلق بالزيتون
        if "زيتون" not in question and "olive" not in question.lower():
            return Response(
                {"response": "هذه الصفحة متخصصة في أمراض شجر الزيتون فقط."},
                status=status.HTTP_200_OK
            )

        # 🔍 تحديد اللغة
        try:
            language = langdetect.detect(question)
        except:
            language = 'en'  # لغة افتراضية في حال الفشل

        # ✏️ تخصيص الطلب بحسب اللغة
        if language == 'ar':
            prompt = f"أجب فقط عن أمراض شجر الزيتون المتعلقة بالسؤال التالي، ولا تتحدث عن أي شيء آخر:\n{question}"
        else:
            prompt = f"Only answer about diseases of olive trees related to the following question. Do not mention anything unrelated:\n{question}"

        # إعداد البيانات للإرسال إلى Gemini
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ]
        }

        try:
            response = requests.post(
                f"{GEMINI_API_URL}?key={API_KEY}",
                json=payload
            )

            if response.status_code == 200:
                gemini_response = response.json()
                answer = gemini_response['candidates'][0]['content']['parts'][0]['text']
                return Response({"response": answer}, status=status.HTTP_200_OK)
            else:
                error_message = response.json().get('error', {}).get('message', 'Unknown error')
                return Response({"error": f"Gemini API Error: {error_message}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
