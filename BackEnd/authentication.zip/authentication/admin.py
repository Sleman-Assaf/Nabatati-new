from django.contrib import admin
from .models import CustomUser
from django.contrib import admin

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('email', 'name', 'role', 'status', 'is_active')
    list_filter = ('role', 'status')
    search_fields = ('email', 'name')