from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model

User = get_user_model()

class AuthenticationTests(APITestCase):
    def setUp(self):
        # Create test users
        self.regular_user = User.objects.create_user(
            email='user@example.com',
            name='Regular User',
            password='testpass123',
            role='user'
        )
        
        self.engineer = User.objects.create_user(
            email='engineer@example.com',
            name='Test Engineer',
            password='testpass123',
            role='engineer',
            membership_number='ENG123456',
            specialization='Agriculture',
            status=1  # Active
        )
        
        self.admin = User.objects.create_user(
            email='admin@example.com',
            name='Test Admin',
            password='testpass123',
            role='admin',
            is_staff=True
        )
        
        # URLs
        self.login_url = reverse('token_obtain_pair')
        self.register_url = reverse('user_register')
        self.engineer_register_url = reverse('engineer_register')
        self.user_detail_url = reverse('user_detail')
        print(self.user_detail_url)
        self.refresh_url = reverse('token_refresh')
        self.logout_url = reverse('logout')
        self.change_password_url = reverse('change_password')

    def test_register_user(self):
        data = {
            'email': 'newuser@example.com',
            'name': 'New User',
            'password': 'newpassword123',
            'password2': 'newpassword123',
            'role': 'user'
        }
        response = self.client.post(self.register_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.count(), 4)  # 3 initial + 1 new
        self.assertEqual(User.objects.get(email='newuser@example.com').name, 'New User')

    def test_register_engineer(self):
        data = {
            'email': 'newengineer@example.com',
            'name': 'New Engineer',
            'password': 'newpassword123',
            'password2': 'newpassword123',
            'role': 'engineer',
            'membership_number': 'ENG789012',
            'specialization': 'Plant Diseases'
        }
        response = self.client.post(self.engineer_register_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.count(), 4)  # 3 initial + 1 new
        new_engineer = User.objects.get(email='newengineer@example.com')
        self.assertEqual(new_engineer.role, 'engineer')
        self.assertEqual(new_engineer.status, 0)  # Should be pending

    def test_login_user(self):
        data = {
            'email': 'user@example.com',
            'password': 'testpass123'
        }
        response = self.client.post(self.login_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('access' in response.data)
        self.assertTrue('refresh' in response.data)

    def test_login_engineer(self):
        data = {
            'email': 'engineer@example.com',
            'password': 'testpass123'
        }
        response = self.client.post(self.login_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('access' in response.data)
        self.assertTrue('refresh' in response.data)

    def test_get_user_detail(self):
        # Login first to get token
        login_data = {
            'email': 'user@example.com',
            'password': 'testpass123'
        }
        login_response = self.client.post(self.login_url, login_data, format='json')
        token = login_response.data['access']
        
        # Use token to access profile
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
        response = self.client.get(self.user_detail_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['email'], 'user@example.com')
        self.assertEqual(response.data['role'], 'user')

    def test_token_refresh(self):
        login_data = {
            'email': 'user@example.com',
            'password': 'testpass123'
        }
        login_response = self.client.post(self.login_url, login_data, format='json')
        refresh_token = login_response.data['refresh']
        
        data = {'refresh': refresh_token}
        response = self.client.post(self.refresh_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('access' in response.data)

    def test_change_password(self):
        # Login first to get token
        login_data = {
            'email': 'user@example.com',
            'password': 'testpass123'
        }
        login_response = self.client.post(self.login_url, login_data, format='json')
        token = login_response.data['access']
        
        # Change password
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')
        change_password_data = {
            'current_password': 'testpass123',
            'new_password': 'newtestpass456'
        }
        response = self.client.put(self.change_password_url, change_password_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # Try to login with new password
        new_login_data = {
            'email': 'user@example.com',
            'password': 'newtestpass456'
        }
        response = self.client.post(self.login_url, new_login_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue('access' in response.data)