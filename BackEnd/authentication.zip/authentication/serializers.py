from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

User = get_user_model()

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Add custom claims
        token['email'] = user.email
        token['name'] = user.name
        token['role'] = user.role

        # Add engineer-specific claims if applicable
        if user.role == 'engineer':
            token['status'] = user.status
            token['specialization'] = user.specialization
            token['membership_number'] = user.membership_number

        return token

    def validate(self, attrs):
        data = super().validate(attrs)

        # ✅ المنع هنا إذا كان المهندس لم تتم الموافقة عليه
        if self.user.role == 'engineer' and self.user.status == 0:
            raise serializers.ValidationError("Your account is pending approval. Please wait for admin approval.")

        return data



class UserRegisterSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(
        required=True,
        validators=[UniqueValidator(queryset=User.objects.all())]
    )
    password = serializers.CharField(
        write_only=True, 
        required=True, 
        validators=[validate_password]
    )
    password2 = serializers.CharField(write_only=True, required=True)

    class Meta:
        model = User
        fields = ('email', 'password', 'password2', 'name', 'role')
        extra_kwargs = {
            'name': {'required': True},
            'role': {'required': True}
        }

    def validate(self, attrs):
        if attrs['password'] != attrs['password2']:
            raise serializers.ValidationError({"password": "Password fields didn't match."})
        
        # Validate role is one of the allowed values
        if attrs['role'] not in [role[0] for role in User.USER_ROLES]:
            raise serializers.ValidationError({"role": "Invalid role selected."})
        
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2')
        role = validated_data.get('role')
        
        user = User.objects.create(
            email=validated_data['email'],
            name=validated_data['name'],
            role=role,
            auth_provider='email'
        )
        
        user.set_password(validated_data['password'])
        user.save()
        
        return user

class EngineerRegisterSerializer(UserRegisterSerializer):
    membership_number = serializers.CharField(required=True)
    specialization = serializers.CharField(required=True)
    cv_file = serializers.CharField(required=False, allow_blank=True)

    class Meta(UserRegisterSerializer.Meta):
        fields = UserRegisterSerializer.Meta.fields + ('membership_number', 'specialization', 'cv_file')

    def validate(self, attrs):
        attrs = super().validate(attrs)
        
        # Ensure role is set to engineer
        attrs['role'] = 'engineer'
        
        # Check if membership number is unique
        if User.objects.filter(membership_number=attrs['membership_number']).exists():
            raise serializers.ValidationError({"membership_number": "This membership number is already in use."})
        
        return attrs

    def create(self, validated_data):
        validated_data.pop('password2')
        
        # Set initial status to pending (0)
        validated_data['status'] = 0
        
        user = User.objects.create(
            email=validated_data['email'],
            name=validated_data['name'],
            role='engineer',
            auth_provider='email',
            membership_number=validated_data['membership_number'],
            specialization=validated_data['specialization'],
            cv_file=validated_data.get('cv_file', ''),
            status=validated_data['status']
        )
        
        user.set_password(validated_data['password'])
        user.save()
        
        return user

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'name', 'role', 'auth_provider', 'created_at')
        read_only_fields = ('id', 'role', 'auth_provider', 'created_at')

class EngineerSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'name', 'role', 'specialization', 'membership_number', 
                 'status', 'cv_file', 'created_at')
        read_only_fields = ('id', 'role', 'status', 'created_at')

class AdminSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'name', 'role', 'created_at')
        read_only_fields = ('id', 'role', 'created_at')

class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, validators=[validate_password])