from django.contrib import admin
from contact.models import ContactMessage  # أو من .models إذا في نفس التطبيق

@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('email', 'phone', 'created_at')